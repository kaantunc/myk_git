<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

if (file_exists(JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php') ) {

		if (!defined('_COMMUNITY_ACL_ADMIN_HOME')) {
			define('_COMMUNITY_ACL_ADMIN_HOME', JPATH_SITE.'/administrator/components/com_community_acl/');
		}
		if (session_id() == "") @session_start();
		
		require_once (JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php'); 
		$db	=& JFactory::getDBO();
		$query = "SELECT `id` FROM  `#__community_acl_sites` WHERE `is_main` = '1'";
		$db->setQuery($query);
		$sid = (int)$db->loadResult();
		if ($sid > 0) {
			$main = new CACL_site($db);
			$main->load($sid);
		
			$config = new CACL_config($main->_site_db);
			$config->load();
		}else {
			$config = new CACL_config($db);
			$config->load();
		}
		
		if (!$config->synchronize || !$config->users_and_cb) {
			return;
		} else {		
			$_PLUGINS->registerFunction( 'onAfterUpdateUser', 'cacl_plugin_after_user_update' ); 
			
			$_PLUGINS->registerFunction( 'onAfterUserApproval', 'cacl_plugin_user_approval' );
			$_PLUGINS->registerFunction( 'onAfterNewUser', 'cacl_plugin_new_user' );
			$_PLUGINS->registerFunction( 'onBeforeUserBlocking', 'cacl_plugin_user_block' ); 
			
			$_PLUGINS->registerFunction( 'onAfterUserUpdate', 'cacl_plugin_after_user_update' );
			
			$_PLUGINS->registerFunction( 'onAfterUserRegistration', 'cacl_plugin_user_reg' );
			$_PLUGINS->registerFunction( 'onAfterLogin', 'cacl_plug_on_login' );
			$_PLUGINS->registerFunction( 'onAfterUserConfirm', 'cacl_plugin_user_confirm' );
			
			$_PLUGINS->registerFunction( 'onNewPassword', 'cacl_plugin_user_newpassword' );
			
			$_PLUGINS->registerFunction( 'onAfterDeleteUser', 'cacl_plugin_user_delete' );
			
			$_PLUGINS->registerFunction( 'onUserActive', 'cacl_plugin_user_active' );		
	
	
			$_PLUGINS->registerFunction( 'onBeforeUserActive', 'cacl_plugin_before_user_active' );
		}
}

function cacl_plugin_user_block($user, $actionValue){
	require_once (JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php'); 
	
	$db	=& JFactory::getDBO();
	$query = "UPDATE #__users SET block = " . (int) $actionValue . " WHERE id = " . (int) $user->id;
	$db->setQuery($query);
	$db->query();
	
	$query = "SELECT `id` FROM  `#__community_acl_sites` WHERE `is_main` = '1'";
	$db->setQuery($query);
	$sid = (int)$db->loadResult();
	if ($sid > 0) {
		$main = new CACL_site($db);
		$main->load($sid);
		
		$config = new CACL_config($main->_site_db);
		$config->load();
		
		if (!$config->synchronize || !$config->users_and_cb) 
			return;
			
		$sync = new CACL_syncronize($main); 
		$sync->syncronize($user->id, 'user');
	}
	return; 
}

function cacl_plugin_user_approval(&$user, $approved) {
	require_once (JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php'); 
	$db	=& JFactory::getDBO();
	
	$query = "SELECT `id` FROM  `#__community_acl_sites` WHERE `is_main` = '1'";
	$db->setQuery($query);
	$sid = (int)$db->loadResult();
	if ($sid > 0) {
		$main = new CACL_site($db);
		$main->load($sid);
	
		$config = new CACL_config($main->_site_db);
		$config->load();
		
		if (!$config->synchronize || !$config->users_and_cb) 
			return;
				
		$sync = new CACL_syncronize($main);
		$sync->syncronize($user->id, 'user'); 
		$sync->syncronize($user->id, 'cb_user');
	}
	return; 
}



function cacl_plugin_new_user(&$user, &$cbUser) {
	require_once (JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php'); 
	$db	=& JFactory::getDBO();
	
	$query = "SELECT `id` FROM  `#__community_acl_sites` WHERE `is_main` = '1'";
	$db->setQuery($query);
	$sid = (int)$db->loadResult();
	if ($sid > 0) {
		$main = new CACL_site($db);
		$main->load($sid);
	
		$config = new CACL_config($main->_site_db);
		$config->load();
		
		if (!$config->synchronize || !$config->users_and_cb) 
			return;
		
		$sync = new CACL_syncronize($main);
		$sync->syncronize($user->id, 'user'); 
		$sync->syncronize($user->id, 'cb_user');

	}

	return;
}



function cacl_plug_on_login($user, &$cbUser) {
	global $mainframe;
	require_once (JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php'); 
	$db	=& JFactory::getDBO();
	
	$query = "SELECT `id` FROM  `#__community_acl_sites` WHERE `is_main` = '1'";
	$db->setQuery($query);
	$sid = (int)$db->loadResult();
	if ($sid > 0) {
		$main = new CACL_site($db);
		$main->load($sid);
	
		$config = new CACL_config($main->_site_db);
		$config->load();
		
		if (!$config->synchronize || !$config->users_and_cb) 
			return;
		
		$sync = new CACL_syncronize($main);
		$sync->syncronize($user->id, 'user'); 
		$sync->syncronize($user->id, 'cb_user');
	}
	$mainframe->redirect('index.php?option=com_community_acl&task=redirect');
	
	return;
}



function cacl_plugin_user_confirm($user) {
	require_once (JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php'); 
	$db	=& JFactory::getDBO();
	
	$query = "SELECT `id` FROM  `#__community_acl_sites` WHERE `is_main` = '1'";
	$db->setQuery($query);
	$sid = (int)$db->loadResult();
	if ($sid > 0) {
		$main = new CACL_site($db);
		$main->load($sid);
	
		$config = new CACL_config($main->_site_db);
		$config->load();
		
		if (!$config->synchronize || !$config->users_and_cb) 
			return;
		
		$sync = new CACL_syncronize($main);
		$sync->syncronize($user->id, 'cb_user');

	}

	return;
}

function cacl_plugin_user_reg(&$user,&$cbUser) {
	require_once (JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php'); 
	$db	=& JFactory::getDBO();
	
	$query = "SELECT `id` FROM  `#__community_acl_sites` WHERE `is_main` = '1'";
	$db->setQuery($query);
	$sid = (int)$db->loadResult();
	if ($sid > 0) {
		$main = new CACL_site($db);
		$main->load($sid);
	
		$config = new CACL_config($main->_site_db);
		$config->load();
		
		if (!$config->synchronize || !$config->users_and_cb) 
			return;
		
		$sync = new CACL_syncronize($main);
		$sync->syncronize($user->id, 'user'); 
		$sync->syncronize($user->id, 'cb_user');
	}
	return;
}

function cacl_plugin_user_newpassword(&$uid, &$pass) {	
	require_once (JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php'); 
	jimport('joomla.user.helper');
	
	$newpass = $pass;
	$salt  = JUserHelper::genRandomPassword(32);
	$crypt = JUserHelper::getCryptedPassword($newpass, $salt);
	$newpass = $crypt.':'.$salt;

	$db	=& JFactory::getDBO();
	$query = "UPDATE `#__users` SET `password` = '" . $newpass . "' WHERE `id` = " . (int) $uid;
	$db->setQuery($query);
	$db->query();
	
	$query = "SELECT `id` FROM  `#__community_acl_sites` WHERE `is_main` = '1'";
	$db->setQuery($query);
	$sid = (int)$db->loadResult();
	if ($sid > 0) {
		$main = new CACL_site($db);
		$main->load($sid);
	
		$config = new CACL_config($main->_site_db);
		$config->load();
		
		if (!$config->synchronize || !$config->users_and_cb) 
			return;
		
		$sync = new CACL_syncronize($main); 
		$sync->syncronize($user->id, 'user');
	}
	return; 	
}

function cacl_plugin_after_user_update( $user, $cbUser ) {
	require_once (JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php'); 
	$db	=& JFactory::getDBO();
	
	$query = "SELECT `id` FROM  `#__community_acl_sites` WHERE `is_main` = '1'";
	$db->setQuery($query);
	$sid = (int)$db->loadResult();
	if ($sid > 0) {
		$main = new CACL_site($db);
		$main->load($sid);
	
		$config = new CACL_config($main->_site_db);
		$config->load();
		
		if (!$config->synchronize || !$config->users_and_cb) 
			return;
		
		$sync = new CACL_syncronize($main);
		$sync->syncronize($user->id, 'user'); 
		$sync->syncronize($user->id, 'cb_user');
	}
	return;
}

function cacl_plugin_user_delete(&$user) {
	require_once (JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php'); 
	$db	=& JFactory::getDBO();
	
	$query = "SELECT `id` FROM  `#__community_acl_sites` WHERE `is_main` = '1'";
	$db->setQuery($query);
	$sid = (int)$db->loadResult();
	if ($sid > 0) {
		$main = new CACL_site($db);
		$main->load($sid);
	
		$config = new CACL_config($main->_site_db);
		$config->load();
		
		if (!$config->synchronize || !$config->users_and_cb) 
			return;
		
		$sync = new CACL_syncronize($main);
		$sync->syncronize($user->id, 'user_delete');
		$sync->syncronize($user->id, 'cb_user_delete');
	}
	return;
}

function cacl_plugin_user_active($user){
	require_once (JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php'); 
	$db	=& JFactory::getDBO();
	
	$query = "SELECT `id` FROM  `#__community_acl_sites` WHERE `is_main` = '1'";
	$db->setQuery($query);
	$sid = (int)$db->loadResult();
	if ($sid > 0) {
		$main = new CACL_site($db);
		$main->load($sid);
	
		$config = new CACL_config($main->_site_db);
		$config->load();
		
		if (!$config->synchronize || !$config->users_and_cb) 
			return;	
	
		$sync = new CACL_syncronize($main);
		$sync->syncronize($user->id, 'user'); 
		$sync->syncronize($user->id, 'cb_user');

	}

	return;
}

function cacl_plugin_before_user_active($user, $ui, $cause, $mailToAdmins, $mailToUser){
	require_once (JPATH_SITE.'/administrator/components/com_community_acl/community_acl.class.php'); 
	$db	=& JFactory::getDBO();
	
	$query = "SELECT `id` FROM  `#__community_acl_sites` WHERE `is_main` = '1'";
	$db->setQuery($query);
	$sid = (int)$db->loadResult();
	if ($sid > 0) {
		$main = new CACL_site($db);
		$main->load($sid);
	
		$config = new CACL_config($main->_site_db);
		$config->load();
		
		if (!$config->synchronize || !$config->users_and_cb) 
			return;	
	
		$sync = new CACL_syncronize($main);
		$sync->syncronize($user->id, 'user'); 
		$sync->syncronize($user->id, 'cb_user');

	}

	return;
}



?>